# Morta7 Minimal Project

This is a minimal scaffold prepared for Render deployment. See README.deploy.md for deployment notes.
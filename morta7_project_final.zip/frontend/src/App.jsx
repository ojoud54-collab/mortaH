import React from 'react';
export default function App(){ return <div><h2>Mortah Frontend</h2></div>; }